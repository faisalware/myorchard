from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
import qrcode
import os
import requests
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'secret'
UPLOAD_FOLDER = 'static/uploads/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
DB = 'database.db'

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def init_db():
    with sqlite3.connect(DB) as conn:
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, password TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS plants (
                        id INTEGER PRIMARY KEY, 
                        user_id INTEGER, 
                        name TEXT, 
                        type TEXT,
                        photo TEXT
                    )''')
        c.execute('''CREATE TABLE IF NOT EXISTS updates (
                        id INTEGER PRIMARY KEY, 
                        plant_id INTEGER, 
                        update TEXT, 
                        date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )''')

init_db()

def get_weather(city="New York"):
    API_KEY = "YOUR_API_KEY"
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
    try:
        response = requests.get(url)
        data = response.json()
        return {
            "temp": data["main"]["temp"],
            "humidity": data["main"]["humidity"],
            "weather": data["weather"][0]["main"]
        }
    except:
        return {"temp": "N/A", "humidity": "N/A", "weather": "N/A"}

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        name = request.form['username']
        pwd = request.form['password']
        with sqlite3.connect(DB) as conn:
            c = conn.cursor()
            c.execute("SELECT * FROM users WHERE username=? AND password=?", (name, pwd))
            user = c.fetchone()
            if user:
                session['user_id'] = user[0]
                return redirect('/dashboard')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    user_id = session.get('user_id')
    with sqlite3.connect(DB) as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM plants WHERE user_id=?", (user_id,))
        plants = c.fetchall()
    weather = get_weather("New York")
    return render_template('dashboard.html', plants=plants, weather=weather)

@app.route('/add_plant', methods=['GET', 'POST'])
def add_plant():
    if request.method == 'POST':
        name = request.form['name']
        plant_type = request.form['type']
        photo = request.files['photo']
        filename = secure_filename(photo.filename)
        photo.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        user_id = session.get('user_id')
        with sqlite3.connect(DB) as conn:
            c = conn.cursor()
            c.execute("INSERT INTO plants (user_id, name, type, photo) VALUES (?, ?, ?, ?)", 
                      (user_id, name, plant_type, filename))
            conn.commit()
            plant_id = c.lastrowid
            qr = qrcode.make(f"http://localhost:5000/plant/{plant_id}")
            qr.save(f"static/qr_{plant_id}.png")
        return redirect('/dashboard')
    return render_template('add_plant.html')

@app.route('/plant/<int:plant_id>', methods=['GET', 'POST'])
def plant_detail(plant_id):
    if request.method == 'POST':
        update_text = request.form['update']
        with sqlite3.connect(DB) as conn:
            c = conn.cursor()
            c.execute("INSERT INTO updates (plant_id, update) VALUES (?, ?)", (plant_id, update_text))
    with sqlite3.connect(DB) as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM plants WHERE id=?", (plant_id,))
        plant = c.fetchone()
        c.execute("SELECT * FROM updates WHERE plant_id=? ORDER BY date DESC", (plant_id,))
        updates = c.fetchall()
    return render_template('plant_detail.html', plant=plant, updates=updates)

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')
